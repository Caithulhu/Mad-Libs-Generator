'''
Mad Libs Generator
-------------------------------------------------------------
'''

# Questions for the user to answer

number = input('Choose a number: ')

adjective = input('Choose an adjective: ')

noun = input('Choose a noun: ')

noun2 = input('Choose a noun: ')

adjective2 = input('Choose an adjective: ')

p_noun = input('Choose a plural noun: ')

verb = input('Choose a verb -ing: ')

verb2 = input('Choose a verb -ing: ')

beverage = input('Choose a beverage: ')

food = input('Choose a food: ')

# The story from the user input

print('------------------------------------------')

print('Winter is one of', number, 'seasons of the year.')

print('Some other seasons are', adjective, 'and', noun+ ".")

print('Winter is the time of year when the', noun2, 'is furthest from the Earth.')

print('The weather tends to be', adjective2, 'in winter with lots of')

print(p_noun, 'and cold temperatures.')

print('Some winter sports include', verb, 'and', verb2 + ".")

print('Hot', beverage, 'with', food, 'on top is a popular winter drink.')

print('------------------------------------------')